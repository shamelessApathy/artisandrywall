<?php

/* Template Name: Boxed*/

get_template_part('page');