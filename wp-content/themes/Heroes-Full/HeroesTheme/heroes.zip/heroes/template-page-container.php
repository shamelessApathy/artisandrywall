<?php

/* Template Name: With Container */

fwp_settings::set_var('show_container', true);

get_template_part('page');

?>