<?php

/**
Here lives template for author.
Change this just if you need custom author page different than default view
**/

get_template_part('index');