<?php

/**
Here lives template for tag. 
Change this just if you need custom tag page different than default view
**/

get_template_part('index');