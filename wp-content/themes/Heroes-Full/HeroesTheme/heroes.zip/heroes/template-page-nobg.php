<?php

/* Template Name: Transparent BG */

fwp_settings::set_var('fwp_pageClass', 'fwp-no-bg-color');

get_template_part('template-page-full');