<?php

/**
Here lives template for archive. 
Change this just if you need custom archive page different than default view
**/

get_template_part('index');